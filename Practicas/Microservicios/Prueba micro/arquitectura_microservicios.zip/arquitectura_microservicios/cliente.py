"""
cliente.py — Cliente gRPC que envía expresiones matemáticas al orquestador.

Uso interactivo:
    python3 cliente.py

Uso con argumento directo:
    python3 cliente.py --expr "5+3*2-1" --host localhost --port 50060
"""

import argparse
import grpc
from protos import calculadora_pb2, calculadora_pb2_grpc


def calcular(stub, expr: str) -> str:
    """Envía la expresión al orquestador y devuelve el resultado como texto."""
    try:
        respuesta = stub.Calcular(calculadora_pb2.Expresion(expr=expr))
        campo = respuesta.WhichOneof("resultado")
        if campo == "data":
            return f" {expr} = {respuesta.data}"
        else:
            return f" Error: {respuesta.error}"
    except grpc.RpcError as e:
        return f" Error gRPC: {e.details()}"


def modo_interactivo(stub):
    """Bucle interactivo para ingresar expresiones desde la terminal."""
    print("\n")
    print("   Calculadora distribuida gRPC       ")
    print("   Escribe una expresión matemática   ")
    print("   Ejemplo: 5+3*2-1  |  10/2+4        ")
    print("   Escribe 'salir' para terminar      ")

    while True:
        try:
            expr = input(">>> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nHasta luego.")
            break

        if not expr:
            continue
        if expr.lower() in ("salir", "exit", "q"):
            print("Hasta luego.")
            break

        print("   ", calcular(stub, expr))


def main():
    parser = argparse.ArgumentParser(description="Cliente de la calculadora distribuida")#172.31.7.137
    parser.add_argument("--host", type=str, default="172.31.7.137",
                        help="IP o hostname del orquestador")
    parser.add_argument("--port", type=int, default=8000,
                        help="Puerto del orquestador")
    parser.add_argument("--expr", type=str, default=None,
                        help="Expresión a calcular (si se omite, modo interactivo)")
    args = parser.parse_args()

    canal = grpc.insecure_channel(f"{args.host}:{args.port}")
    
    #grpc.channel_ready_future(canal).result(timeout=5)

    stub  = calculadora_pb2_grpc.OrquestadorServiceStub(canal)

    if args.expr:
        print(calcular(stub, args.expr))
    else:
        modo_interactivo(stub)


if __name__ == "__main__":
    main()
